/* ============================================================
   LOYED — seed data (simulated backend dataset)
   In production these come from the API server.
   ============================================================ */
var LOYED_DATA = {

  app: {
    name: "LOYED",
    tagline: "ONE PLATFORM. EVERY CONNECTION. EVERY POSSIBILITY.",
    subTagline: "BEYOND THE SYSTEM",
    version: "1.0.0-proto",
    ownerContact: "+20 100 000 0000",
    defaultLang: "ar",
  },

  me: {
    id: "u_me",
    name: "زائر LOYED",
    loyedId: "@loyed_me",
    phone: "+20 100 123 4567",
    phoneHidden: false,
    phoneVisibility: "contacts", // everyone | contacts | nobody | selected
    avatarColor: 0,
    about: "متاح على LOYED",
    status: "online",
    lastSeen: Date.now(),
    plan: "free",
    theme: "cyberpunk",
    lang: "ar",
    accountState: "active",
  },

  contacts: [
    {id:"u1", name:"أحمد المصري", loyedId:"@ahmed_eg", phone:"+20 100 111 1111", online:true, lastSeen:Date.now()-120000, about:"في القاهرة 🇪🇬", color:1},
    {id:"u2", name:"سارة عبدالله", loyedId:"@sara_sa", phone:"+966 50 222 2222", online:false, lastSeen:Date.now()-3600000, about:"تصميم وفن", color:2},
    {id:"u3", name:"خالد الدوسري", loyedId:"@khaled_kw", phone:"+965 55 333 3333", online:true, lastSeen:Date.now()-30000, about:"ريادة أعمال", color:3},
    {id:"u4", name:"Yuki Tanaka", loyedId:"@yuki_jp", phone:"+81 90 4444 4444", online:false, lastSeen:Date.now()-86400000, about:"東京にいる", color:4},
    {id:"u5", name:"Emily Clark", loyedId:"@emily_us", phone:"+1 555 555 5555", online:true, lastSeen:Date.now()-10000, about:"Designer @ NYC", color:5},
    {id:"u6", name:"Lucas Müller", loyedId:"@lucas_de", phone:"+49 66 666 6666", online:false, lastSeen:Date.now()-7200000, about:"Berlin", color:6},
    {id:"u7", name:"مالك العتيبي", loyedId:"@malik_sa", phone:"+966 56 777 7777", online:false, lastSeen:Date.now()-1800000, about:"طالب", color:7},
    {id:"u8", name:"فاطمة الزهراء", loyedId:"@fatima_ma", phone:"+212 6 88 88 88 88", online:true, lastSeen:Date.now()-60000, about:"كاتبة", color:8},
    {id:"u9", name:"Bot Weather", loyedId:"@weather_bot", phone:"", online:true, lastSeen:Date.now(), about:"بوت الطقس", color:9, isBot:true},
    {id:"u10", name:"LOYED Support", loyedId:"@loyed_support", phone:"", online:true, lastSeen:Date.now(), about:"الدعم الرسمي", color:0, isOfficial:true},
  ],

  chats: [
    {id:"c1", peer:"u1", kind:"direct", pinned:true, muted:false, unread:2, draft:"",
     messages:[
       {id:"m1", from:"u1", text:"السلام عليكم، أخبارك إيه؟", t:Date.now()-3600000, status:"read"},
       {id:"m2", from:"me", text:"وعليكم السلام، الحمد لله تمام. إنت عامل إيه؟", t:Date.now()-3500000, status:"read"},
       {id:"m3", from:"u1", text:"كله تمام، عاوز أكلمك في موضوع المشروع الجديد", t:Date.now()-600000, status:"delivered"},
       {id:"m4", from:"u1", text:"فيه حاجة مهمة 🚀", t:Date.now()-300000, status:"delivered"},
     ]},
    {id:"c2", peer:"u5", kind:"direct", pinned:false, muted:false, unread:0, draft:"",
     messages:[
       {id:"m1", from:"u5", text:"Hey, did you see the new design?", t:Date.now()-7200000, status:"read"},
       {id:"m2", from:"me", text:"Yes, it looks amazing! 🔥", t:Date.now()-7000000, status:"read"},
     ]},
    {id:"c3", peer:"u3", kind:"direct", pinned:false, muted:true, unread:5, draft:"",
     messages:[
       {id:"m1", from:"u3", text:"أبشر، خلصت التقرير", t:Date.now()-900000, status:"delivered"},
     ]},
    {id:"c4", kind:"group", name:"فريق LOYED", desc:"فريق التطوير", members:["me","u1","u3","u5","u9"], admins:["me","u1"], pinned:true, muted:false, unread:12, messages:[
       {id:"m1", from:"u1", text:"اجتماع الساعة 8 مساءً", t:Date.now()-5400000, status:"read"},
       {id:"m2", from:"u3", text:"تمام، هكون موجود", t:Date.now()-5300000, status:"read"},
       {id:"m3", from:"u9", text:"🌤️ طقس القاهرة: 24°، صحو", t:Date.now()-3600000, status:"read"},
       {id:"m4", from:"u5", text:"I'll join too", t:Date.now()-120000, status:"delivered"},
     ]},
    {id:"c5", kind:"channel", name:"LOYED Updates", desc:"آخر تحديثات المنصة", subscribers:18420, verified:true, pinned:false, muted:false, unread:1, messages:[
       {id:"m1", from:"u10", text:"📢 تم إطلاق LOYED BOT STUDIO للجميع", t:Date.now()-86400000, status:"read"},
       {id:"m2", from:"u10", text:"✨ ثيم Purple Neon الجديد متاح بالمجاني", t:Date.now()-43200000, status:"delivered"},
     ]},
  ],

  statuses: [
    {id:"s1", userId:"u1", type:"text", text:"يوم جديد، فرصة جديدة 🌅", t:Date.now()-3600000, views:18},
    {id:"s2", userId:"u5", type:"text", text:"Shipping the new design today ✨", t:Date.now()-7200000, views:42},
    {id:"s3", userId:"u8", type:"text", text:"كتاب جديد في الطريق 📚", t:Date.now()-10800000, views:7},
    {id:"s4", userId:"u3", type:"text", text:"اجتماع ناجح اليوم 🤝", t:Date.now()-14400000, views:23},
  ],

  calls: [
    {id:"cl1", peer:"u1", dir:"in", type:"voice", t:Date.now()-7200000, duration:"3:42", missed:false},
    {id:"cl2", peer:"u5", dir:"out", type:"video", t:Date.now()-3600000, duration:"12:08", missed:false},
    {id:"cl3", peer:"u2", dir:"in", type:"voice", t:Date.now()-1800000, duration:"0:00", missed:true},
    {id:"cl4", peer:"u4", dir:"out", type:"voice", t:Date.now()-86400000, duration:"5:20", missed:false},
  ],

  servers: [
    {id:"sv1", name:"LOYED Community", icon:"💜", members:12480, channels:[
      {id:"t1", name:"general", type:"text"},
      {id:"t2", name:"announcements", type:"text"},
      {id:"v1", name:"Lounge", type:"voice", users:["u1","u3"]},
      {id:"v2", name:"Gaming", type:"voice", users:[]},
    ]},
    {id:"sv2", name:"Tech Hub", icon:"💻", members:3210, channels:[
      {id:"t1", name:"dev-talk", type:"text"},
      {id:"t2", name:"help", type:"text"},
      {id:"v1", name:"Stage", type:"stage", users:["u5"]},
    ]},
    {id:"sv3", name:"Egypt Devs", icon:"🇪🇬", members:890, channels:[
      {id:"t1", name:"general", type:"text"},
      {id:"t2", name:"jobs", type:"text"},
    ]},
  ],

  social: [
    {id:"p1", userId:"u5", text:"Just shipped the new LOYED chat UI. Cyberpunk vibes all the way 💜✨", likes:234, comments:18, reposts:12, t:Date.now()-3600000},
    {id:"p2", userId:"u1", text:"النهاردة اجتماع رائع مع فريق LOYED. مستقبل المنصة مبشر جداً 🚀", likes:189, comments:24, reposts:8, t:Date.now()-7200000},
    {id:"p3", userId:"u8", text:"كتاب جديد قادم قريباً... تفاصيل خلال أيام 📖✨", likes:412, comments:56, reposts:33, t:Date.now()-10800000},
  ],

  bots: [
    {id:"b1", name:"Weather Bot", loyedId:"@weather_bot", lang:"ar", active:true, users:1240, desc:"يقدم حالة الطقس لأي مدينة"},
    {id:"b2", name:"Translate Bot", loyedId:"@translate_bot", lang:"multi", active:true, users:890, desc:"ترجمة فورية للرسائل"},
    {id:"b3", name:"Reminder Bot", loyedId:"@remind_bot", lang:"ar", active:false, users:230, desc:"تذكير بالمواعيد"},
  ],

  store: [
    {id:"st1", name:"Cyberpunk Theme", cat:"theme", price:0, icon:"🌃"},
    {id:"st2", name:"Galaxy Theme", cat:"theme", price:0, icon:"🌌"},
    {id:"st3", name:"Purple Neon Theme", cat:"theme", price:0, icon:"💜"},
    {id:"st4", name:"Aurora Pack", cat:"theme", price:2.99, icon:"🌈"},
    {id:"st5", name:"Neon Stickers", cat:"sticker", price:1.99, icon:"✨"},
    {id:"st6", name:"Emoji Pack Pro", cat:"emoji", price:0.99, icon:"😎"},
    {id:"st7", name:"Cyber Fonts", cat:"font", price:1.49, icon:"🔤"},
    {id:"st8", name:"Glass Icons", cat:"icon", price:0.99, icon:"🔮"},
  ],

  cloud: [
    {id:"f1", name:"Project_LOYED.pdf", size:"2.4 MB", type:"pdf", t:Date.now()-86400000},
    {id:"f2", name:"design_v2.png", size:"1.8 MB", type:"image", t:Date.now()-172800000},
    {id:"f3", name:"meeting_rec.m4a", size:"12 MB", type:"audio", t:Date.now()-259200000},
    {id:"f4", name:"backup_chat.json", size:"540 KB", type:"data", t:Date.now()-432000000},
  ],

  academy: [
    {id:"a1", title:"أساسيات تطوير الويب", teacher:"u5", students:1240, lessons:24, level:"مبتدئ"},
    {id:"a2", title:"الذكاء الاصطناعي للمبتدئين", teacher:"u1", students:890, lessons:18, level:"متوسط"},
    {id:"a3", title:"تصميم UI/UX", teacher:"u5", students:2100, lessons:32, level:"متقدم"},
  ],

  games: [
    {id:"g1", name:"LOYED Quiz", players:420, desc:"اختبار معلومات عامة", icon:"❓"},
    {id:"g2", name:"Word Battle", players:180, desc:"تحدي الكلمات بين الأصدقاء", icon:"📝"},
    {id:"g3", name:"Trivia Rush", players:310, desc:"مسابقة سريعة ضد الوقت", icon:"⚡"},
  ],

  // ---- OWNER: members for management ----
  members: [
    {id:"u1", name:"أحمد المصري", loyedId:"@ahmed_eg", state:"active", plan:"free", joined:Date.now()-86400000*120, country:"🇪🇬 EG"},
    {id:"u2", name:"سارة عبدالله", loyedId:"@sara_sa", state:"active", plan:"pro", joined:Date.now()-86400000*90, country:"🇸🇦 SA"},
    {id:"u3", name:"خالد الدوسري", loyedId:"@khaled_kw", state:"active", plan:"free", joined:Date.now()-86400000*60, country:"🇰🇼 KW"},
    {id:"u4", name:"Yuki Tanaka", loyedId:"@yuki_jp", state:"active", plan:"free", joined:Date.now()-86400000*45, country:"🇯🇵 JP"},
    {id:"u5", name:"Emily Clark", loyedId:"@emily_us", state:"online", plan:"pro", joined:Date.now()-86400000*200, country:"🇺🇸 US"},
    {id:"u7", name:"مالك العتيبي", loyedId:"@malik_sa", state:"muted", plan:"free", joined:Date.now()-86400000*30, country:"🇸🇦 SA", mute:"chat", until:Date.now()+86400000, reason:"إزعاج متكرر"},
    {id:"u8", name:"فاطمة الزهراء", loyedId:"@fatima_ma", state:"active", plan:"free", joined:Date.now()-86400000*15, country:"🇲🇦 MA"},
    {id:"u11", name:"Test User", loyedId:"@test_x", state:"suspended", plan:"free", joined:Date.now()-86400000*10, country:"🇪🇬 EG", reason:"انتهاك السياسة"},
  ],

  // ---- FEATURES for OWNER FEATURE CONTROL ----
  features: [
    {id:"feat_chat", name:"LOYED Chat — المحادثات", cat:"chat", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_groups", name:"المجموعات", cat:"chat", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_channels", name:"LOYED Channels", cat:"chat", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_status", name:"LOYED Status", cat:"social", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_calls", name:"LOYED Call (صوت/فيديو)", cat:"call", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_group_call", name:"المكالمات الجماعية", cat:"call", status:"paid", enabled:true, price:4.99, users:"pro"},
    {id:"feat_hide_phone", name:"إخفاء رقم الهاتف", cat:"privacy", status:"paid", enabled:true, price:2.99, users:"pro"},
    {id:"feat_disappear", name:"الرسائل ذاتية الاختفاء", cat:"chat", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_schedule", name:"الرسائل المجدولة", cat:"chat", status:"paid", enabled:true, price:1.99, users:"pro"},
    {id:"feat_servers", name:"LOYED Servers (ديسكورد)", cat:"community", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_social", name:"LOYED Social", cat:"social", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_live", name:"LOYED Live — البث المباشر", cat:"media", status:"paid", enabled:true, price:3.99, users:"pro"},
    {id:"feat_academy", name:"LOYED Academy", cat:"edu", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_bots", name:"LOYED Bot Studio", cat:"dev", status:"free", enabled:false, price:0, users:"all"},
    {id:"feat_ai", name:"LOYED AI Assistant", cat:"ai", status:"paid", enabled:true, price:5.99, users:"pro"},
    {id:"feat_translate", name:"الترجمة الذكية", cat:"ai", status:"paid", enabled:true, price:1.99, users:"pro"},
    {id:"feat_voice_text", name:"تحويل الصوت إلى نص", cat:"ai", status:"paid", enabled:true, price:1.99, users:"pro"},
    {id:"feat_cloud", name:"LOYED Cloud (تخزين أكبر)", cat:"storage", status:"paid", enabled:true, price:2.99, users:"pro"},
    {id:"feat_store", name:"LOYED Store", cat:"custom", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_gaming", name:"LOYED Gaming", cat:"fun", status:"free", enabled:true, price:0, users:"all"},
    {id:"feat_custom_themes", name:"الثيمات المخصصة", cat:"custom", status:"paid", enabled:true, price:0.99, users:"pro"},
  ],

  subscriptionRequests: [
    {id:"r1", userId:"u1", feature:"feat_hide_phone", featureName:"إخفاء رقم الهاتف", t:Date.now()-3600000, status:"pending"},
    {id:"r2", userId:"u7", feature:"feat_ai", featureName:"LOYED AI Assistant", t:Date.now()-7200000, status:"pending"},
    {id:"r3", userId:"u4", feature:"feat_group_call", featureName:"المكالمات الجماعية", t:Date.now()-86400000, status:"pending"},
  ],

  reports: [
    {id:"rp1", reporter:"u2", target:"u11", reason:"محتوى مخالف", chat:"c_general", t:Date.now()-3600000, status:"open"},
    {id:"rp2", reporter:"u5", target:"u7", reason:"إزعاج", chat:"c4", t:Date.now()-7200000, status:"open"},
  ],

  moderationLog: [
    {id:"lg1", admin:"owner", action:"CHAT MUTE", target:"u7", reason:"إزعاج متكرر", t:Date.now()-3600000},
    {id:"lg2", admin:"owner", action:"APP SUSPENSION", target:"u11", reason:"انتهاك السياسة", t:Date.now()-86400000},
  ],

  stats: {
    totalUsers: 18420,
    activeNow: 1240,
    messagesToday: 89420,
    callsToday: 1820,
    newSignups: 312,
    proSubscribers: 890,
    groups: 1240,
    channels: 420,
    servers: 89,
  },

  languages: [
    {code:"ar", name:"العربية", native:"العربية", dir:"rtl", flag:"🇪🇬"},
    {code:"ar-eg", name:"مصرية", native:"مصري", dir:"rtl", flag:"🇪🇬"},
    {code:"en", name:"English", native:"English", dir:"ltr", flag:"🇺🇸"},
    {code:"en-gb", name:"British English", native:"English (UK)", dir:"ltr", flag:"🇬🇧"},
    {code:"fr", name:"French", native:"Français", dir:"ltr", flag:"🇫🇷"},
    {code:"de", name:"German", native:"Deutsch", dir:"ltr", flag:"🇩🇪"},
    {code:"es", name:"Spanish", native:"Español", dir:"ltr", flag:"🇪🇸"},
    {code:"ja", name:"Japanese", native:"日本語", dir:"ltr", flag:"🇯🇵"},
    {code:"ko", name:"Korean", native:"한국어", dir:"ltr", flag:"🇰🇷"},
    {code:"zh", name:"Chinese (Simplified)", native:"简体中文", dir:"ltr", flag:"🇨🇳"},
    {code:"zh-tw", name:"Chinese (Traditional)", native:"繁體中文", dir:"ltr", flag:"🇹🇼"},
    {code:"ru", name:"Russian", native:"Русский", dir:"ltr", flag:"🇷🇺"},
    {code:"tr", name:"Turkish", native:"Türkçe", dir:"ltr", flag:"🇹🇷"},
    {code:"fa", name:"Persian", native:"فارسی", dir:"rtl", flag:"🇮🇷"},
    {code:"hi", name:"Hindi", native:"हिन्दी", dir:"ltr", flag:"🇮🇳"},
    {code:"ur", name:"Urdu", native:"اردو", dir:"rtl", flag:"🇵🇰"},
    {code:"pt", name:"Portuguese", native:"Português", dir:"ltr", flag:"🇵🇹"},
    {code:"it", name:"Italian", native:"Italiano", dir:"ltr", flag:"🇮🇹"},
  ],

  // owner code — in production this is verified server-side via HMAC, never stored as plaintext in client.
  // Here it is only a demo gate. The real secret lives in server config.
  _ownerCodeHashHint: "LO****ED/YA****HIA",
};

// ---- i18n strings ----
var LOYED_I18N = {
  ar: {
    chats:"المحادثات", status:"الحالات", calls:"المكالمات", servers:"السيرفرات",
    social:"السوشيال", more:"المزيد", settings:"الإعدادات", search:"بحث",
    newChat:"محادثة جديدة", newGroup:"مجموعة جديدة", newChannel:"قناة جديدة",
    broadcast:"بث", starred:"مفضلة", archived:"مؤرشفة",
    online:"متصل الآن", offline:"غير متصل", typing:"يكتب الآن...", lastSeen:"آخر ظهور",
    delivered:"تم التسليم", read:"تمت القراءة", sent:"تم الإرسال",
    sendMessage:"اكتب رسالة...", reply:"رد", forward:"إعادة توجيه", copy:"نسخ",
    edit:"تعديل", delete:"حذف", deleteBoth:"حذف لدى الطرفين", pin:"تثبيت",
    reactions:"التفاعلات", markImportant:"تمييز كمهم", mute:"كتم", unmute:"إلغاء الكتم",
    profile:"الملف الشخصي", logout:"تسجيل الخروج", loyed:"LOYED",
    ownerControl:"LOYED OWNER CONTROL", back:"رجوع", cancel:"إلغاء", save:"حفظ", done:"تم",
  },
  en: {
    chats:"Chats", status:"Status", calls:"Calls", servers:"Servers",
    social:"Social", more:"More", settings:"Settings", search:"Search",
    newChat:"New Chat", newGroup:"New Group", newChannel:"New Channel",
    broadcast:"Broadcast", starred:"Starred", archived:"Archived",
    online:"Online", offline:"Offline", typing:"typing...", lastSeen:"last seen",
    delivered:"Delivered", read:"Read", sent:"Sent",
    sendMessage:"Type a message...", reply:"Reply", forward:"Forward", copy:"Copy",
    edit:"Edit", delete:"Delete", deleteBoth:"Delete for both", pin:"Pin",
    reactions:"Reactions", markImportant:"Mark Important", mute:"Mute", unmute:"Unmute",
    profile:"Profile", logout:"Log Out", loyed:"LOYED",
    ownerControl:"LOYED OWNER CONTROL", back:"Back", cancel:"Cancel", save:"Save", done:"Done",
  }
};
