/* ============================================================
   LOYED OWNER CONTROL — owner dashboard & feature control
   ============================================================ */
var LOYEDOwner = (function(){
  var S = LOYEDStore;
  var UI = LOYEDUI;
  var api = {};
  var current = "dashboard";

  function render(root){
    root.innerHTML = panelHTML();
    bindSide();
    api.show("dashboard");
  }

  function panelHTML(){
    var st=S.get();
    var h='<div class="owner-side"><div class="owner-side-head"><div><div class="logo-glow">LOYED</div><div class="osh-sub">OWNER CONTROL</div></div></div>';
    var items=[
      ["dashboard","📊","لوحة المعلومات"],
      ["members","👥","الأعضاء",st.members.length],
      ["admins","🛡️","المشرفون"],
      ["permissions","🔑","الصلاحيات"],
      ["features","⚡","التحكم بالمميزات"],
      ["subscriptions","💎","الاشتراكات",st.subscriptionRequests.filter(function(r){return r.status==="pending";}).length],
      ["moderation","⚖️","العقوبات والميوت"],
      ["reports","🚩","البلاغات",st.reports.filter(function(r){return r.status==="open";}).length],
      ["privacy","🔒","الخصوصية"],
      ["messages","💬","الرسائل"],
      ["channels","📢","القنوات"],
      ["servers","🛡️","السيرفرات"],
      ["bots","🤖","البوتات"],
      ["ai","✨","LOYED AI"],
      ["store","🛍️","المتجر"],
      ["themes","🎨","الثيمات"],
      ["languages","🌐","اللغات"],
      ["academy","🎓","الأكاديمية"],
      ["ads","📣","الإعلانات"],
      ["stats","📈","الإحصائيات"],
      ["security","🔐","الأمان"],
      ["updates","⬆️","التحديثات"],
      ["maintenance","🛠️","الصيانة"],
      ["logs","📜","سجل الإدارة"],
    ];
    items.forEach(function(it){
      h+='<div class="os-item" data-section="'+it[0]+'"><span class="osi-ico">'+it[1]+'</span><span>'+it[2]+'</span>'+(it[3]?'<span class="osi-badge">'+it[3]+'</span>':'')+'</div>';
    });
    h+='<div style="padding:14px;border-top:1px solid var(--border);margin-top:auto"><button class="btn-ghost btn-sm" style="width:100%" onclick="LOYEDUI.closeOwner()">⟵ خروج</button></div>';
    h+='</div>';
    h+='<div class="owner-main"><div class="owner-topbar"><h1 id="otTitle">لوحة المعلومات</h1><div class="spacer"></div><span class="badge-soft">صاحب التطبيق 👑</span></div><div class="owner-content" id="ownerContent"></div></div>';
    return h;
  }

  function bindSide(){
    document.querySelectorAll(".os-item").forEach(function(el){
      el.addEventListener("click", function(){ api.show(el.dataset.section); });
    });
  }

  function show(section){
    current=section;
    document.querySelectorAll(".os-item").forEach(function(el){ el.classList.toggle("active", el.dataset.section===section); });
    var titles={dashboard:"لوحة المعلومات",members:"إدارة الأعضاء",admins:"المشرفون",permissions:"الصلاحيات",features:"LOYED MASTER FEATURE CONTROL",subscriptions:"الاشتراكات وطلباتها",moderation:"العقوبات والميوت",reports:"البلاغات",privacy:"إعدادات الخصوصية",messages:"الرسائل",channels:"القنوات",servers:"السيرفرات",bots:"البوتات",ai:"LOYED AI",store:"المتجر",themes:"الثيمات",languages:"اللغات",academy:"الأكاديمية",ads:"الإعلانات",stats:"الإحصائيات",security:"الأمان",updates:"التحديثات",maintenance:"الصيانة",logs:"سجل الإدارة"};
    document.getElementById("otTitle").textContent=titles[section]||section;
    var c=document.getElementById("ownerContent");
    var fn=SECTIONS[section]||SECTIONS.dashboard;
    c.innerHTML=fn();
  }

  /* ---------- helpers ---------- */
  function statCard(l,v,tr){ return '<div class="stat-card"><div class="sc-label">'+l+'</div><div class="sc-val">'+v+'</div><div class="sc-trend">'+tr+'</div></div>'; }
  function pillClass(s){return {active:"active",online:"active",muted:"muted",restricted:"muted",suspended:"suspended",banned:"banned","under review":"review","temporarily suspended":"suspended"}[s]||"off";}
  function stateLabel(s){return {active:"Active",online:"Online",muted:"Muted",restricted:"Restricted",suspended:"Suspended",banned:"Banned","under review":"Under Review","temporarily suspended":"Temp. Suspended"}[s]||s;}
  function ownerSwitch(t,k){ return '<div class="set-row"><span class="sr-ico">⚙️</span><div class="sr-body"><div class="sr-title">'+t+'</div></div><label class="switch"><input type="checkbox" onchange="LOYEDOwner.toast(\'تم الحفظ\')"/><span class="slider"></span></label></div>'; }
  function catLabel(c){return {chat:"💬 المحادثات",social:"🌐 السوشيال",call:"📞 المكالمات",privacy:"🔒 الخصوصية",community:"🛡️ المجتمعات",media:"📡 الوسائط",edu:"🎓 التعليم",dev:"🤖 التطوير",ai:"✨ الذكاء الاصطناعي",storage:"☁️ التخزين",custom:"🎨 التخصيص",fun:"🎮 الترفيه"}[c]||c;}
  function label(k){return {totalUsers:"إجمالي الأعضاء",activeNow:"متصل الآن",messagesToday:"رسائل اليوم",callsToday:"مكالمات اليوم",newSignups:"تسجيلات جديدة",proSubscribers:"مشتركو Pro",groups:"المجموعات",channels:"القنوات",servers:"السيرفرات"}[k]||k;}
  function mgmtList(title, items, kind){
    var h='<div class="card" style="padding:0;overflow:hidden"><div style="padding:14px;border-bottom:1px solid var(--border);font-weight:700;display:flex;align-items:center"><span>'+title+'</span><div class="spacer"></div><button class="btn-sm btn-primary" onclick="LOYEDOwner.toast(\'إضافة — تجريبي\')">＋</button></div><div class="list">';
    items.forEach(function(it){
      var ico={channel:"📢",server:"🛡️",bot:"🤖",store:"🛍️",academy:"🎓"}[kind]||"📋";
      h+='<div class="list-item"><div class="avatar sm" style="background:var(--elev)">'+ico+'</div><div class="li-body"><div class="li-name">'+it.name+'</div><div class="li-msg">'+it.sub+'</div></div><button class="btn-sm btn-ghost" onclick="LOYEDOwner.toast(\'تعديل\')">تعديل</button></div>';
    });
    h+='</div></div>';
    return h;
  }
  function memberRow(m){
    var u=S.findContact(m.id);
    var av='<div class="avatar sm" style="background:'+S.avatarColor(u.color||0)+'">'+S.initials(m.name)+'</div>';
    var statePill='<span class="pill '+pillClass(m.state)+'">'+stateLabel(m.state)+'</span>';
    var planPill='<span class="pill '+(m.plan==="pro"?"paid":"free")+'">'+(m.plan==="pro"?"Pro 💎":"مجاني")+'</span>';
    var actions='<div class="row-flex" style="gap:4px"><button class="icon-btn btn-sm" title="تفاصيل" onclick="LOYEDOwner.memberDetail(\''+m.id+'\')">ℹ️</button><button class="icon-btn btn-sm" title="عقوبة" onclick="LOYEDOwner.moderate(\''+m.id+'\')">⚖️</button><button class="icon-btn btn-sm" title="مميزات" onclick="LOYEDOwner.memberFeatures(\''+m.id+'\')">⚡</button></div>';
    return '<tr data-name="'+m.name+'"><td><div class="row-flex">'+av+'<div><div style="font-weight:600">'+m.name+'</div><div style="font-size:11px;color:var(--muted)">'+S.fmtTime(m.joined)+'</div></div></div></td><td><span class="kbd">'+m.loyedId+'</span></td><td>'+statePill+'</td><td>'+planPill+'</td><td>'+m.country+'</td><td>'+actions+'</td></tr>';
  }
  function featureRow(f){
    var enabledPill=f.enabled?'<span class="pill active">مفعّل</span>':'<span class="pill off">معطّل</span>';
    var statusPill=f.status==="free"?'<span class="pill free">مجاني</span>':'<span class="pill paid">مدفوع $'+f.price+'</span>';
    var h='<div class="fc-row"><div style="flex:1"><div class="fc-name">'+f.name+'</div><div class="fc-sub">'+f.cat+' · '+(f.users==="all"?"للجميع":f.users)+'</div></div>';
    h+='<div class="fc-actions">'+enabledPill+statusPill+'</div></div>';
    h+='<div class="fc-actions" style="margin-top:8px;flex-wrap:wrap">';
    h+='<button class="btn-sm '+(f.enabled?'btn-ghost':'btn-primary')+'" onclick="LOYEDOwner.toggleFeat(\''+f.id+'\')">'+(f.enabled?'إيقاف':'تفعيل')+'</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featStatus(\''+f.id+'\',\'free\')">مجاني</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featStatus(\''+f.id+'\',\'paid\')">مدفوع</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featPrice(\''+f.id+'\')">السعر</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featMaint(\''+f.id+'\')">صيانة</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featSchedule(\''+f.id+'\')">جدولة</button>';
    h+='<button class="btn-sm btn-ghost" onclick="LOYEDOwner.featStopAll(\''+f.id+'\')">إيقاف شامل</button>';
    h+='</div></div>';
    return h;
  }

  /* ---------- SECTIONS ---------- */
  var SECTIONS={};

  SECTIONS.dashboard=function(){
    var st=S.get();
    var h='<div class="stat-grid">';
    h+=statCard("إجمالي الأعضاء", st.stats.totalUsers, "+312 اليوم");
    h+=statCard("متصل الآن", st.stats.activeNow, "مباشر");
    h+=statCard("رسائل اليوم", st.stats.messagesToday, "+12%");
    h+=statCard("مكالمات اليوم", st.stats.callsToday, "+5%");
    h+=statCard("مشترك Pro", st.stats.proSubscribers, "💎");
    h+=statCard("المجموعات", st.stats.groups, "");
    h+=statCard("القنوات", st.stats.channels, "");
    h+=statCard("السيرفرات", st.stats.servers, "");
    h+='</div>';
    h+='<div class="grid grid-2"><div class="card"><h3>📈 نشاط آخر 7 أيام</h3>';
    h+='<div style="display:flex;align-items:flex-end;gap:6px;height:120px;margin-top:14px">';
    [40,65,52,78,90,72,95].forEach(function(v){ h+='<div style="flex:1;background:linear-gradient(180deg,var(--accent),var(--accent-2));height:'+v+'%;border-radius:6px 6px 0 0;box-shadow:var(--glow)"></div>'; });
    h+='</div></div>';
    h+='<div class="card"><h3>⚠️ إجراءات تحتاج انتباهك</h3><div class="list" style="margin-top:10px">';
    var pending=st.subscriptionRequests.filter(function(r){return r.status==="pending";}).length;
    var openRep=st.reports.filter(function(r){return r.status==="open";}).length;
    h+='<div class="list-item" onclick="LOYEDOwner.show(\'subscriptions\')"><div class="avatar sm" style="background:var(--elev)">💎</div><div class="li-body"><div class="li-name">طلبات اشتراك معلّقة</div><div class="li-msg">'+pending+' طلب</div></div></div>';
    h+='<div class="list-item" onclick="LOYEDOwner.show(\'reports\')"><div class="avatar sm" style="background:var(--elev)">🚩</div><div class="li-body"><div class="li-name">بلاغات مفتوحة</div><div class="li-msg">'+openRep+' بلاغ</div></div></div>';
    h+='<div class="list-item" onclick="LOYEDOwner.show(\'moderation\')"><div class="avatar sm" style="background:var(--elev)">⚖️</div><div class="li-body"><div class="li-name">أعضاء تحت تقييد</div><div class="li-msg">'+st.members.filter(function(m){return m.state!=="active"&&m.state!=="online";}).length+' عضو</div></div></div>';
    h+='</div></div></div>';
    h+='<div class="card" style="margin-top:14px"><h3>⚡ حالة الأنظمة</h3><div class="grid grid-4" style="margin-top:10px">';
    [["LOYED Chat","online"],["المكالمات","online"],["السيرفرات","online"],["LOYED AI","online"],["Bot Studio","maintenance"],["LOYED Live","online"],["الأكاديمية","online"],["المتجر","online"]].forEach(function(s){
      h+='<div style="text-align:center;padding:10px;background:var(--bg-2);border-radius:10px"><div class="dot '+(s[1]==="online"?"online":"busy")+'" style="margin-bottom:6px"></div><div style="font-size:12px;font-weight:600">'+s[0]+'</div><div style="font-size:10px;color:var(--muted)">'+(s[1]==="online"?"يعمل":"صيانة")+'</div></div>';
    });
    h+='</div></div>';
    return h;
  };

  SECTIONS.members=function(){
    var st=S.get();
    var h='<div class="set-row" style="margin-bottom:14px"><input class="search-box" style="width:100%" placeholder="بحث عن عضو..." oninput="LOYEDOwner.filterMembers(this.value)"/><div class="spacer"></div><span class="badge-soft">'+st.members.length+' عضو</span></div>';
    h+='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>العضو</th><th>LOYED ID</th><th>الحالة</th><th>الخطة</th><th>الدولة</th><th>إجراءات</th></tr></thead><tbody id="membersBody">';
    st.members.forEach(function(m){ h+=memberRow(m); });
    h+='</tbody></table></div>';
    h+='<p style="font-size:11px;color:var(--muted);margin-top:10px">يمكن للمالك تطبيق العقوبات، تفعيل/إيقاف المميزات لكل عضو، وإجباره على إعدادات خصوصية محددة. المشرفون العاديون لا يستطيعون معاقبة المالك.</p>';
    return h;
  };

  SECTIONS.admins=function(){
    var h='<div class="card" style="margin-bottom:14px"><h3>هرم الصلاحيات</h3><div class="list" style="margin-top:10px">';
    [["👑","Application Owner","صاحب التطبيق الأساسي، السلطة النهائية على كل الأنظمة"],
     ["⭐","Super Owner","بتفويض صريح من المالك فقط، صلاحيات محددة"],
     ["🛡️","Admin / Moderator","صلاحيات يمنحها المالك فقط"],
     ["👤","Member","عضو عادي يستخدم المميزات المتاحة"]].forEach(function(r){
      h+='<div class="list-item"><div class="avatar sm" style="background:var(--elev)">'+r[0]+'</div><div class="li-body"><div class="li-name">'+r[1]+'</div><div class="li-msg">'+r[2]+'</div></div></div>';
    });
    h+='</div></div>';
    var st=S.get();
    h+='<div class="card"><h3>المشرفون الحاليون</h3><div class="list" style="margin-top:10px">';
    st.members.slice(0,2).forEach(function(m){
      h+='<div class="list-item"><div class="avatar sm" style="background:linear-gradient(135deg,#6366f1,#4f46e5)">🛡️</div><div class="li-body"><div class="li-name">'+m.name+'</div><div class="li-msg">'+m.loyedId+' · Admin</div></div><button class="btn-sm btn-ghost" onclick="LOYEDOwner.toast(\'تعديل الصلاحيات\')">تعديل</button></div>';
    });
    h+='</div></div>';
    h+='<div class="card" style="margin-top:14px;background:rgba(255,77,109,.08);border-color:var(--danger)"><h3 style="color:var(--danger)">🚫 ممنوع على المشرفين</h3><ul style="font-size:13px;color:var(--muted);padding-inline-start:18px;line-height:2"><li>ترقية أنفسهم</li><li>تغيير صلاحيات المالك</li><li>الوصول للوحة المالك دون إذن</li><li>منح أنفسهم مميزات مدفوعة</li><li>تعديل كود المالك</li><li>إلغاء عقوبات المالك</li><li>الوصول لبيانات غير مصرح بها</li></ul></div>';
    return h;
  };

  SECTIONS.permissions=function(){
    var perms=[
      ["إدارة الأعضاء","owner","admin"],
      ["تطبيق العقوبات","owner","admin"],
      ["إلغاء عقوبات المالك","owner"],
      ["إدارة المشرفين","owner","super"],
      ["التحكم بالمميزات","owner"],
      ["إدارة الاشتراكات","owner","admin"],
      ["إدارة المتجر","owner","admin"],
      ["إدارة الثيمات","owner"],
      ["إدارة اللغات","owner"],
      ["إدارة LOYED AI","owner"],
      ["عرض السجلات","owner","super"],
      ["تعديل كود المالك","owner"],
      ["إيقاف ميزة للصيانة","owner","super"],
      ["إدارة التحديثات","owner"],
    ];
    var h='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>الصلاحية</th><th>المالك</th><th>Super</th><th>Admin</th></tr></thead><tbody>';
    perms.forEach(function(p){
      h+='<tr><td>'+p[0]+'</td><td>'+(p.indexOf("owner")>=0?'<span class="pill active">✓</span>':'')+'</td><td>'+(p.indexOf("super")>=0?'<span class="pill active">✓</span>':'<span class="pill off">—</span>')+'</td><td>'+(p.indexOf("admin")>=0?'<span class="pill active">✓</span>':'<span class="pill off">—</span>')+'</td></tr>';
    });
    h+='</tbody></table></div>';
    h+='<p style="font-size:11px;color:var(--muted);margin-top:10px">المشرف العادي لا يستطيع إيقاف المالك أو معاقبته أو تغيير صلاحياته.</p>';
    return h;
  };

  SECTIONS.features=function(){
    var st=S.get();
    var h='<div class="card" style="margin-bottom:14px;background:linear-gradient(135deg,var(--panel-2),var(--panel))"><h3>⚡ LOYED MASTER FEATURE CONTROL</h3><p style="color:var(--muted);font-size:13px;margin-top:6px">تحكم حقيقي من جهة الخادم لكل ميزة: تفعيل/تعطيل، مجاني/مدفوع، السعر، المدة، منح مجاني، إيقاف عن عضو/مجموعة/الجميع، تجربة مجانية، صيانة، وجدولة التفعيل.</p></div>';
    var cats={};
    st.features.forEach(function(f){ cats[f.cat]=cats[f.cat]||[]; cats[f.cat].push(f); });
    Object.keys(cats).forEach(function(cat){
      h+='<div class="set-section"><h2>'+catLabel(cat)+'</h2>';
      cats[cat].forEach(function(f){ h+=featureRow(f); });
      h+='</div>';
    });
    return h;
  };

  SECTIONS.subscriptions=function(){
    var st=S.get();
    var h='<div class="stat-grid" style="margin-bottom:14px">'+statCard("مشتركو Pro",st.stats.proSubscribers,"💎")+statCard("إيراد تقديري/شهر","$"+(st.stats.proSubscribers*4.99).toFixed(0),"")+statCard("طلبات معلّقة",st.subscriptionRequests.filter(function(r){return r.status==="pending";}).length,"")+statCard("نسبة التحويل","68%","")+'</div>';
    h+='<div class="card" style="padding:0;overflow:hidden"><div style="padding:14px;border-bottom:1px solid var(--border);font-weight:700">📋 طلبات الاشتراك</div><div class="list">';
    st.subscriptionRequests.forEach(function(r){
      var m=st.members.find(function(x){return x.id===r.userId;})||S.findContact(r.userId);
      var name=m?m.name:r.userId;
      var pill='<span class="pill '+(r.status==="pending"?"muted":r.status==="approved"?"active":"off")+'">'+r.status+'</span>';
      h+='<div class="list-item"><div class="avatar sm" style="background:var(--elev)">💎</div><div class="li-body"><div class="li-name">'+name+' — '+r.featureName+'</div><div class="li-msg">'+S.fmtTime(r.t)+'</div></div>'+pill+(r.status==="pending"?'<div class="row-flex" style="gap:4px"><button class="btn-sm btn-primary" onclick="LOYEDOwner.approveSub(\''+r.id+'\')">قبول</button><button class="btn-sm btn-ghost" onclick="LOYEDOwner.rejectSub(\''+r.id+'\')">رفض</button></div>':'')+'</div>';
    });
    if(st.subscriptionRequests.length===0) h+='<div class="empty">لا توجد طلبات</div>';
    h+='</div></div>';
    h+='<p style="font-size:11px;color:var(--muted);margin-top:10px">يمكنك قبول/رفض الطلب، تفعيل الميزة مجاناً، أو بعد التحقق من الدفع، وتحديد مدة الاشتراك أو منح فترة تجريبية.</p>';
    return h;
  };

  SECTIONS.moderation=function(){
    var st=S.get();
    var h='<div class="set-section"><h2>أنواع العقوبات</h2><div class="grid grid-2">';
    [["CHAT MUTE","منع إرسال الرسائل"],["GROUP MUTE","منع الكتابة في مجموعات محددة"],["VOICE MUTE","منع الرسائل الصوتية"],["CALL RESTRICTION","منع المكالمات"],["MEDIA RESTRICTION","منع إرسال الوسائط"],["TEMPORARY RESTRICTION","تقييد مؤقت"],["FULL COMMUNICATION MUTE","منع كل التواصل"],["APP SUSPENSION","إيقاف الحساب بالكامل"]].forEach(function(a){
      h+='<div class="card"><div style="font-weight:700">'+a[0]+'</div><p>'+a[1]+'</p></div>';
    });
    h+='</div></div>';
    h+='<div class="set-section"><h2>حالات الحساب</h2><div class="row-flex" style="flex-wrap:wrap;gap:6px">';
    ["active","online","offline","muted","restricted","temporarily suspended","suspended","banned","under review"].forEach(function(s){
      h+='<span class="pill '+pillClass(s)+'">'+stateLabel(s)+'</span>';
    });
    h+='</div></div>';
    h+='<div class="set-section"><h2>الأعضاء تحت تقييد حالياً</h2><div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>العضو</th><th>النوع</th><th>السبب</th><th>المدة</th><th></th></tr></thead><tbody>';
    st.members.filter(function(m){return m.state!=="active"&&m.state!=="online";}).forEach(function(m){
      h+='<tr><td>'+m.name+'</td><td><span class="pill muted">'+(m.mute||"—")+'</span></td><td>'+(m.reason||"—")+'</td><td>'+(m.until?S.fmtTime(m.until):"دائم")+'</td><td><button class="btn-sm btn-primary" onclick="LOYEDOwner.liftMod(\''+m.id+'\')">رفع</button></td></tr>';
    });
    h+='</tbody></table></div></div>';
    h+='<div class="set-section"><h2>📜 سجل العقوبات</h2><div class="list">';
    st.moderationLog.forEach(function(l){
      var m=st.members.find(function(x){return x.id===l.target;});
      h+='<div class="list-item"><div class="avatar sm" style="background:var(--elev)">⚖️</div><div class="li-body"><div class="li-name">'+l.action+' — '+(m?m.name:l.target)+'</div><div class="li-msg">'+l.reason+' · '+S.fmtTime(l.t)+'</div></div></div>';
    });
    h+='</div></div>';
    return h;
  };

  SECTIONS.reports=function(){
    var st=S.get();
    var h='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>المُبلّغ</th><th>المُبلّغ عنه</th><th>السبب</th><th>التاريخ</th><th>الحالة</th><th></th></tr></thead><tbody>';
    st.reports.forEach(function(r){
      var rep=S.findContact(r.reporter), tgt=st.members.find(function(m){return m.id===r.target;})||S.findContact(r.target);
      h+='<tr><td>'+rep.name+'</td><td>'+(tgt?tgt.name:r.target)+'</td><td>'+r.reason+'</td><td>'+S.fmtTime(r.t)+'</td><td><span class="pill '+(r.status==="open"?"muted":"active")+'">'+r.status+'</span></td><td><button class="btn-sm btn-primary" onclick="LOYEDOwner.resolveReport(\''+r.id+'\')">معالجة</button></td></tr>';
    });
    h+='</tbody></table></div>';
    return h;
  };

  SECTIONS.privacy=function(){
    var h='<div class="card" style="margin-bottom:14px"><h3>🔒 التحكم في إخفاء رقم الهاتف (لكل عضو)</h3><p style="color:var(--muted);font-size:13px;margin-top:6px">يمكن للمالك: السماح للعضو باستخدام الميزة، إيقافها عنه، إجباره على إعداد محدد، تفعيلها مجاناً، إتاحتها لمجموعة، أو إيقافها عن الجميع. تُعرض حالة الميزة للعضو بوضوح دون تغيير إعداداته سراً.</p></div>';
    h+='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>العضو</th><th>استخدام الميزة</th><th>الإعداد</th><th>إجراءات</th></tr></thead><tbody>';
    S.get().members.forEach(function(m){
      var use=(m.hidePhoneUse!==false);
      h+='<tr><td>'+m.name+'</td><td>'+(use?'<span class="pill active">مسموح</span>':'<span class="pill off">موقوف</span>')+'</td><td><span class="badge-soft">'+(m.forcedPrivacy||"حر")+'</span></td><td><div class="row-flex" style="gap:4px"><button class="btn-sm btn-ghost" onclick="LOYEDOwner.toggleHidePhone(\''+m.id+'\')">'+(use?'إيقاف':'سماح')+'</button><button class="btn-sm btn-primary" onclick="LOYEDOwner.freePhone(\''+m.id+'\')">مجاني</button><button class="btn-sm btn-ghost" onclick="LOYEDOwner.forcePrivacy(\''+m.id+'\')">إجبار</button></div></td></tr>';
    });
    h+='</tbody></table></div>';
    h+='<div class="set-section"><h2>إعدادات الخصوصية العامة</h2>'+ownerSwitch("فرض آخر ظهور مخفي افتراضياً","forceLastSeen")+'</div>';
    return h;
  };

  SECTIONS.messages=function(){
    var h='<div class="card"><h3>📣 بث رسالة لكل الأعضاء</h3><textarea class="reg-input" id="bcastTxt" rows="3" placeholder="اكتب رسالة الإعلان..." style="margin-top:10px"></textarea>';
    h+='<div class="row-flex" style="margin-top:10px;gap:8px"><button class="btn-primary neon" onclick="LOYEDOwner.broadcast()">إرسال للجميع</button><button class="btn-ghost" onclick="LOYEDOwner.toast(\'جدولة بث — تجريبي\')">جدولة</button></div></div>';
    h+='<div class="card" style="margin-top:14px"><h3>📊 إحصائيات الرسائل</h3><div class="stat-grid" style="margin-top:10px">'+statCard("رسائل اليوم",S.get().stats.messagesToday,"")+statCard("متوسط/عضو",(S.get().stats.messagesToday/S.get().stats.totalUsers).toFixed(1),"")+statCard("مجموعات نشطة",S.get().stats.groups,"")+statCard("قنوات نشطة",S.get().stats.channels,"")+'</div></div>';
    return h;
  };

  SECTIONS.channels=function(){ return mgmtList("📢 القنوات", [{name:"LOYED Updates",sub:"18420 مشترك"},{name:"Tech News",sub:"5230 مشترك"}], "channel"); };
  SECTIONS.servers=function(){ var st=S.get(); return mgmtList("🛡️ السيرفرات", st.servers.map(function(s){return {name:s.name,sub:s.members+" عضو"};}), "server"); };
  SECTIONS.bots=function(){ var st=S.get(); return mgmtList("🤖 البوتات", st.bots.map(function(b){return {name:b.name,sub:b.users+" مستخدم"};}), "bot"); };

  SECTIONS.ai=function(){
    var h='<div class="card"><h3>✨ إعدادات LOYED AI</h3>'+ownerSwitch("تفعيل المساعد الذكي","aiEnabled")+ownerSwitch("دعم اللهجة المصرية","aiEgypt")+ownerSwitch("تلخيص المحادثات الطويلة","aiSummary")+ownerSwitch("اقتراح الردود","aiReplies")+ownerSwitch("البحث الذكي داخل المحادثات","aiSearch")+'</div>';
    h+='<div class="card" style="margin-top:14px"><h3>🔒 الخصوصية</h3><p style="color:var(--muted);font-size:13px;margin-top:6px">يجب احترام خصوصية المحادثات وعدم استخدام محتواها في معالجة إضافية دون أساس وموافقة مناسبة.</p>'+ownerSwitch("استخدام المحتوى للتدريب","aiTrain")+'</div>';
    return h;
  };

  SECTIONS.store=function(){ var st=S.get(); return mgmtList("🛍️ عناصر المتجر", st.store.map(function(s){return {name:s.name,sub:(s.price===0?"مجاني":"$"+s.price)};}), "store"); };

  SECTIONS.themes=function(){
    var themes=[["cyberpunk","Cyberpunk","🌃"],["stealth","Stealth","🥷"],["galaxy","Galaxy","🌌"],["neon","Purple Neon","💜"],["classic","Classic Dark","⬛"],["light","Light","☀️"]];
    var h='<div class="grid grid-3">';
    themes.forEach(function(t){ h+='<div class="card"><div style="font-size:30px;text-align:center">'+t[2]+'</div><h3 style="text-align:center;margin-top:8px">'+t[1]+'</h3><div class="row-flex" style="margin-top:10px;gap:6px;justify-content:center"><button class="btn-sm btn-primary" onclick="LOYEDUI.applyTheme(\''+t[0]+'\')">تطبيق</button><button class="btn-sm btn-ghost" onclick="LOYEDOwner.toast(\'تعيين كافتراضي\')">افتراضي</button></div></div>'; });
    h+='</div><div class="card" style="margin-top:14px">'+ownerSwitch("السماح بثيمات مخصصة للمستخدمين","customThemes")+'</div>';
    return h;
  };

  SECTIONS.languages=function(){
    var st=S.get();
    var h='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>اللغة</th><th>الكود</th><th>الاتجاه</th><th>الحالة</th></tr></thead><tbody>';
    st.languages.forEach(function(l){
      h+='<tr><td>'+l.flag+' '+l.native+'</td><td><span class="kbd">'+l.code+'</span></td><td>'+l.dir.toUpperCase()+'</td><td><span class="pill active">متاحة</span></td></tr>';
    });
    h+='</tbody></table></div>';
    h+='<p style="font-size:11px;color:var(--muted);margin-top:10px">دعم أكثر من 100 لغة عند توافر الترجمات. إعدادات منفصلة للغة الواجهة وAI والبوتات والإشعارات.</p>';
    return h;
  };

  SECTIONS.academy=function(){ var st=S.get(); return mgmtList("🎓 الأكاديمية", st.academy.map(function(a){return {name:a.title,sub:a.students+" طالب"}}), "academy"); };

  SECTIONS.ads=function(){
    var h='<div class="card"><h3>📣 إدارة الإعلانات</h3><textarea class="reg-input" rows="2" placeholder="نص الإعلان" style="margin-top:10px"></textarea><div class="row-flex" style="margin-top:10px;gap:8px"><button class="btn-primary neon" onclick="LOYEDOwner.toast(\'تم نشر الإعلان\')">نشر</button><button class="btn-ghost" onclick="LOYEDOwner.toast(\'جدولة\')">جدولة</button></div></div>';
    h+='<div class="card" style="margin-top:14px">'+ownerSwitch("إعلانات داخل المحادثات","inChatAds")+ownerSwitch("إعلانات المتجر","storeAds")+'</div>';
    return h;
  };

  SECTIONS.stats=function(){
    var st=S.get().stats;
    var h='<div class="stat-grid">';
    Object.keys(st).forEach(function(k){ h+=statCard(label(k), st[k], ""); });
    h+='</div>';
    h+='<div class="card" style="margin-top:14px"><h3>📊 توزيع جغرافي</h3><div class="list" style="margin-top:10px">';
    [["🇪🇬 مصر",4200],["🇸🇦 السعودية",3100],["🇦🇪 الإمارات",1800],["🇺🇸 USA",2400],["🇯🇵 اليابان",920],["🇩🇪 ألمانيا",1100]].forEach(function(c){
      h+='<div class="list-item"><div class="li-body"><div class="li-name">'+c[0]+'</div><div class="li-msg">'+c[1]+' عضو</div></div><div style="width:120px;height:6px;background:var(--border);border-radius:3px"><div style="width:'+(c[1]/4200*100)+'%;height:100%;background:linear-gradient(90deg,var(--accent),var(--neon));border-radius:3px"></div></div></div>';
    });
    h+='</div></div>';
    return h;
  };

  SECTIONS.security=function(){
    var h='<div class="card"><h3>🔐 إعدادات الأمان</h3>'+ownerSwitch("فرض المصادقة الثنائية على الجميع","force2FA")+ownerSwitch("كشف النشاط غير المعتاد","anomalyDetect")+ownerSwitch("تشفير المحادثات (مُطبّق)","e2e")+ownerSwitch("حماية البيانات الشخصية","dataProtect")+'</div>';
    h+='<div class="card" style="margin-top:14px"><h3>🔑 كود المالك</h3><p style="color:var(--muted);font-size:13px">يتم تخزين الكود والتحقق منه بأمان جهة الخادم (HMAC)، وليس كنص ظاهر في الكود. يمكن تغييره واستعادته عبر آلية موثوقة.</p><div class="row-flex" style="margin-top:10px;gap:8px"><button class="btn-primary" onclick="LOYEDOwner.changeOwnerCode()">تغيير الكود</button><button class="btn-ghost" onclick="LOYEDOwner.toast(\'استعادة عبر البريد الإلكتروني المسجّل\')">استعادة</button></div></div>';
    h+='<div class="card" style="margin-top:14px"><h3>📜 سجل العمليات الإدارية</h3><p style="color:var(--muted);font-size:13px;margin-top:6px">كل عملية (تغيير صلاحية، عقوبة، تفعيل ميزة) مسجّلة وقابلة للتدقيق.</p></div>';
    return h;
  };

  SECTIONS.updates=function(){
    var h='<div class="card"><h3>⬆️ التحديثات</h3><p>الإصدار الحالي: <b>v'+S.get().app.version+'</b></p>';
    h+='<div class="list" style="margin-top:10px"><div class="list-item"><div class="avatar sm" style="background:var(--elev)">✅</div><div class="li-body"><div class="li-name">v1.0.0</div><div class="li-msg">الإصدار الأولي</div></div></div><div class="list-item"><div class="avatar sm" style="background:var(--elev)">🚧</div><div class="li-body"><div class="li-name">v1.1.0 (قادم)</div><div class="li-msg">مكالمات جماعية + LOYED Academy كامل</div></div></div></div>';
    h+='<div class="row-flex" style="margin-top:10px;gap:8px"><button class="btn-primary neon" onclick="LOYEDOwner.toast(\'دفع التحديث للجميع\')">دفع تحديث إجباري</button><button class="btn-ghost" onclick="LOYEDOwner.toast(\'جدولة\')">جدولة</button></div></div>';
    return h;
  };

  SECTIONS.maintenance=function(){
    var h='<div class="card"><h3>🛠️ الصيانة</h3><p style="color:var(--muted);font-size:13px">إيقاف أي ميزة مؤقتاً للصيانة دون التأثير على باقي الأنظمة.</p></div>';
    h+='<div class="list" style="margin-top:10px">';
    S.get().features.forEach(function(f){
      h+='<div class="set-row"><div class="sr-body"><div class="sr-title">'+f.name+'</div><div class="sr-sub">'+(f.enabled?"يعمل":"متوقف")+'</div></div><button class="btn-sm '+(f.enabled?'btn-ghost':'btn-primary')+'" onclick="LOYEDOwner.toggleFeat(\''+f.id+'\');LOYEDOwner.show(\'maintenance\')">'+(f.enabled?'إيقاف للصيانة':'تشغيل')+'</button></div>';
    });
    h+='</div>';
    h+='<div class="card" style="margin-top:14px"><button class="btn-danger" style="width:100%" onclick="LOYEDOwner.toast(\'وضع الصيانة العامة — سيتم إيقاف التطبيق مؤقتاً\')">⚠️ وضع الصيانة العامة</button></div>';
    return h;
  };

  SECTIONS.logs=function(){
    var st=S.get();
    var h='<div class="card" style="padding:0;overflow:hidden"><table class="table"><thead><tr><th>الإجراء</th><th>المسؤول</th><th>الهدف</th><th>السبب</th><th>التاريخ</th></tr></thead><tbody>';
    st.moderationLog.forEach(function(l){
      var m=st.members.find(function(x){return x.id===l.target;});
      h+='<tr><td><span class="badge-soft">'+l.action+'</span></td><td>'+l.admin+'</td><td>'+(m?m.name:l.target)+'</td><td>'+l.reason+'</td><td>'+S.fmtTime(l.t)+'</td></tr>';
    });
    h+='<tr><td><span class="badge-soft">FEATURE TOGGLE</span></td><td>owner</td><td>feat_bots</td><td>تفعيل</td><td>'+S.fmtTime(Date.now()-7200000)+'</td></tr>';
    h+='<tr><td><span class="badge-soft">SUBSCRIPTION APPROVED</span></td><td>owner</td><td>u2</td><td>—</td><td>'+S.fmtTime(Date.now()-86400000)+'</td></tr>';
    h+='</tbody></table></div>';
    h+='<p style="font-size:11px;color:var(--muted);margin-top:10px">سجل كامل وقابل للتدقيق لكل العمليات الإدارية.</p>';
    return h;
  };

  /* ---------- action handlers (attached to api) ---------- */
  api.render=render;
  api.show=show;
  api.toast=function(m){ UI.toast(m); };
  api.closeAndGo=function(s){ UI.closeModal(); show(s); };

  api.filterMembers=function(q){
    document.querySelectorAll("#membersBody tr").forEach(function(tr){
      tr.style.display=!q||tr.dataset.name.toLowerCase().indexOf(q.toLowerCase())>=0?"":"none";
    });
  };
  api.memberDetail=function(id){
    var m=S.get().members.find(function(x){return x.id===id;});
    var body='<div class="profile-head" style="margin-bottom:14px"><div class="avatar lg" style="background:'+S.avatarColor(0)+'">'+S.initials(m.name)+'</div><div><div class="ph-name">'+m.name+'</div><div class="ph-id">'+m.loyedId+'</div><div class="ph-phone">'+(m.phone||"رقم مخفي")+'</div></div></div>';
    body+='<div class="set-section"><div class="set-row"><span class="sr-ico">📌</span><div class="sr-body"><div class="sr-title">الحالة</div><div class="sr-sub">'+stateLabel(m.state)+'</div></div></div>';
    body+='<div class="set-row"><span class="sr-ico">💎</span><div class="sr-body"><div class="sr-title">الخطة</div><div class="sr-sub">'+(m.plan==="pro"?"LOYED Pro":"مجاني")+'</div></div></div>';
    body+='<div class="set-row"><span class="sr-ico">🌍</span><div class="sr-body"><div class="sr-title">الدولة</div><div class="sr-sub">'+m.country+'</div></div></div>';
    body+='<div class="set-row"><span class="sr-ico">📅</span><div class="sr-body"><div class="sr-title">تاريخ الانضمام</div><div class="sr-sub">'+new Date(m.joined).toLocaleDateString()+'</div></div></div>';
    if(m.reason) body+='<div class="set-row"><span class="sr-ico">⚠️</span><div class="sr-body"><div class="sr-title">سبب التقييد</div><div class="sr-sub" style="color:var(--danger)">'+m.reason+'</div></div></div>';
    body+='</div>';
    UI.modal({title:"تفاصيل العضو",body:body,foot:'<button class="btn-primary" onclick="LOYEDOwner.closeAndGo(\'members\')">إغلاق</button>'});
  };
  api.moderate=function(id){
    var m=S.get().members.find(function(x){return x.id===id;});
    var actions=[["CHAT MUTE","منع إرسال الرسائل"],["GROUP MUTE","منع الكتابة في مجموعات محددة"],["VOICE MUTE","منع الرسائل الصوتية"],["CALL RESTRICTION","منع المكالمات"],["MEDIA RESTRICTION","منع إرسال الصور/الفيديو/الملفات"],["TEMPORARY RESTRICTION","تقييد مؤقت"],["FULL COMMUNICATION MUTE","منع كل وظائف التواصل"],["APP SUSPENSION","إيقاف الحساب بالكامل"]];
    var body='<div class="profile-head" style="margin-bottom:14px"><div class="avatar sm">'+S.initials(m.name)+'</div><div><div style="font-weight:700">'+m.name+'</div><div class="ph-id">'+m.loyedId+'</div></div></div>';
    body+='<label class="reg-label">نوع العقوبة</label><select class="reg-input" id="modAction">';
    actions.forEach(function(a){ body+='<option value="'+a[0]+'">'+a[0]+' — '+a[1]+'</option>'; });
    body+='</select>';
    body+='<label class="reg-label">المدة (ساعات، 0 = دائم)</label><input class="reg-input" id="modDur" type="number" value="24" min="0"/>';
    body+='<label class="reg-label">السبب</label><input class="reg-input" id="modReason" placeholder="سبب العقوبة"/>';
    body+='<p style="font-size:11px;color:var(--muted)">سيُوضح للعضو سبب التقييد ومدته، مع إتاحة تقديم اعتراض.</p>';
    UI.modal({title:"تطبيق عقوبة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-danger" onclick="LOYEDOwner.applyMod(\''+id+'\')">تطبيق العقوبة</button><button class="btn-primary" onclick="LOYEDOwner.liftMod(\''+id+'\')">رفع العقوبة</button>'});
  };
  api.applyMod=function(id){
    var action=document.getElementById("modAction").value;
    var dur=parseInt(document.getElementById("modDur").value)||0;
    var reason=document.getElementById("modReason").value.trim()||"بدون سبب محدد";
    S.applyModeration(id,action,reason,dur?dur*3600000:0);
    UI.closeModal(); show("members"); UI.toast("تم تطبيق العقوبة ⚖️");
  };
  api.liftMod=function(id){ S.liftModeration(id); UI.closeModal(); show("members"); UI.toast("تم رفع العقوبة ✓"); };

  api.memberFeatures=function(id){
    var m=S.get().members.find(function(x){return x.id===id;});
    var st=S.get();
    var body='<p style="color:var(--muted);font-size:13px;margin-bottom:10px">تفعيل/إيقاف المميزات لـ <b>'+m.name+'</b> على مستوى الخادم.</p><div class="list">';
    st.features.forEach(function(f){
      body+='<div class="fc-row"><div class="fc-name">'+f.name+'<div class="fc-sub">'+f.cat+'</div></div><div class="fc-actions"><button class="btn-sm btn-primary" onclick="LOYEDOwner.toast(\'تم تفعيل '+f.name+' مجاناً لـ '+m.name+'\')">تفعيل مجاني</button><button class="btn-sm btn-ghost" onclick="LOYEDOwner.toast(\'تم الإيقاف عن '+m.name+'\')">إيقاف</button></div></div>';
    });
    body+='</div>';
    UI.modal({title:"مميزات العضو: "+m.name,body:body,foot:'<button class="btn-primary" onclick="LOYEDUI.closeModal()">تم</button>'});
  };

  api.toggleFeat=function(id){ var f=S.get().features.find(function(x){return x.id===id;}); S.setFeature(id,{enabled:!f.enabled}); show("features"); UI.toast(f.enabled?"تم الإيقاف":"تم التفعيل"); };
  api.featStatus=function(id,status){ S.setFeature(id,{status:status}); show("features"); UI.toast("تم التحديث"); };
  api.featPrice=function(id){ var f=S.get().features.find(function(x){return x.id===id;}); var p=prompt("السعر ($):", f.price||0); if(p!==null){ S.setFeature(id,{price:parseFloat(p)||0}); show("features"); UI.toast("تم تحديث السعر"); } };
  api.featMaint=function(id){ S.setFeature(id,{enabled:false}); show("features"); UI.toast("تم وضع الميزة في الصيانة 🛠️"); };
  api.featSchedule=function(id){ UI.toast("جدولة التفعيل — قريباً ⏰"); };
  api.featStopAll=function(id){ S.setFeature(id,{enabled:false,users:"none"}); show("features"); UI.toast("تم الإيقاف الشامل"); };

  api.approveSub=function(id){ S.resolveSubscription(id,"approved"); show("subscriptions"); UI.toast("تمت الموافقة ✓"); };
  api.rejectSub=function(id){ S.resolveSubscription(id,"rejected"); show("subscriptions"); UI.toast("تم الرفض"); };
  api.resolveReport=function(id){ var r=S.get().reports.find(function(x){return x.id===id;}); if(r){r.status="resolved"; S.save(); show("reports"); UI.toast("تمت المعالجة ✓");} };

  api.toggleHidePhone=function(id){ var m=S.get().members.find(function(x){return x.id===id;}); m.hidePhoneUse=(m.hidePhoneUse===false); S.save(); show("privacy"); UI.toast("تم التحديث"); };
  api.freePhone=function(id){ UI.toast("تم تفعيل إخفاء الرقم مجاناً للعضو ✓"); };
  api.forcePrivacy=function(id){ var v=prompt("الإعداد الإجباري (everyone/contacts/nobody):","nobody"); if(v){ var m=S.get().members.find(function(x){return x.id===id;}); m.forcedPrivacy=v; S.save(); show("privacy"); UI.toast("تم فرض الإعداد"); } };

  api.broadcast=function(){ var v=document.getElementById("bcastTxt").value.trim(); if(!v){UI.toast("اكتب رسالة");return;} UI.toast("تم بث الرسالة لـ "+S.get().stats.totalUsers+" عضو 📣"); };
  api.changeOwnerCode=function(){ var v=prompt("أدخل الكود الجديد:"); if(v){ UI.toast("تم تحديث الكود على الخادم ✓ (محاكاة)"); } };

  return api;
})();

/* close owner panel */
LOYEDUI.closeOwner = function(){
  LOYEDStore.t().ownerUnlocked=false;
  document.getElementById("ownerPanel").classList.add("hidden");
  LOYEDUI.navTo("chats");
};
