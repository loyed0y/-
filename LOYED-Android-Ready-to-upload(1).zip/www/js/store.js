/* ============================================================
   LOYED — state store (simulated DB layer over localStorage)
   In production replace with real API calls to the LOYED backend.
   ============================================================ */
var LOYEDStore = (function(){

  var KEY = "loyed_state_v1";
  var state = null;

  function deepClone(o){ return JSON.parse(JSON.stringify(o)); }

  function init(){
    try{
      var raw = localStorage.getItem(KEY);
      if(raw){ state = JSON.parse(raw); }
    }catch(e){}
    if(!state){
      state = deepClone(LOYED_DATA);
      state._t = { currentScreen:"chats", currentChat:null, currentServerChannel:null, ownerUnlocked:false };
      save();
    }
    if(!state._t){ state._t = { currentScreen:"chats", currentChat:null, currentServerChannel:null, ownerUnlocked:false }; }
    return state;
  }

  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(state)); }catch(e){}
  }

  function reset(){
    localStorage.removeItem(KEY);
    state = null;
    init();
  }

  function get(){ return state; }
  function set(s){ state = s; save(); }

  // ---- transient (not persisted) ----
  function t(){ return state._t; }

  // ---- helpers ----
  function findContact(id){
    if(id === "me" || id === state.me.id) return state.me;
    return state.contacts.find(function(c){return c.id===id;}) || {id:id, name:"مستخدم", loyedId:"@"+id, phone:"", online:false};
  }

  function findChat(id){ return state.chats.find(function(c){return c.id===id;}); }

  function sendMsg(chatId, text, from){
    var chat = findChat(chatId); if(!chat) return null;
    if(!chat.messages) chat.messages = [];
    var msg = { id:"m"+Date.now()+Math.floor(Math.random()*999), from:(from||"me"), text:text, t:Date.now(), status:"sent" };
    chat.messages.push(msg);
    // simulate server delivery: sent -> delivered after 600ms -> read after 2.5s
    setTimeout(function(){ msg.status="delivered"; save(); if(LOYEDUI) LOYEDUI.refreshChatTicks(chatId, msg.id); }, 600);
    setTimeout(function(){ msg.status="read"; save(); if(LOYEDUI) LOYEDUI.refreshChatTicks(chatId, msg.id); }, 2500);
    save();
    return msg;
  }

  function deleteMsg(chatId, msgId, both){
    var chat = findChat(chatId); if(!chat) return;
    chat.messages = chat.messages.filter(function(m){return m.id!==msgId;});
    save();
  }

  function editMsg(chatId, msgId, text){
    var chat = findChat(chatId); if(!chat) return;
    var m = chat.messages.find(function(x){return x.id===msgId;});
    if(m){ m.text = text; m.edited = true; save(); }
  }

  function setChatMute(chatId, muted){
    var c = findChat(chatId); if(c){ c.muted=muted; save(); }
  }

  function togglePin(chatId){
    var c = findChat(chatId); if(c){ c.pinned=!c.pinned; save(); }
  }

  function markRead(chatId){
    var c = findChat(chatId); if(c){ c.unread=0; save(); }
  }

  function createChat(peerId, kind, name){
    var id = "c"+Date.now();
    var chat = {id:id, kind:(kind||"direct"), pinned:false, muted:false, unread:0, draft:"", messages:[]};
    if(kind==="direct") chat.peer = peerId;
    else { chat.name=name||"مجموعة"; chat.members=["me"]; chat.admins=["me"]; }
    state.chats.unshift(chat);
    save();
    return chat;
  }

  function setTheme(theme){
    state.me.theme = theme;
    document.documentElement.setAttribute("data-theme", theme);
    document.body.className = "theme-"+theme;
    save();
  }

  function setLang(lang){
    state.me.lang = lang;
    var langDef = state.languages.find(function(l){return l.code===lang;}) || {dir:"rtl"};
    document.documentElement.lang = lang;
    document.documentElement.dir = langDef.dir;
    save();
  }

  function setMe(patch){
    Object.assign(state.me, patch);
    save();
  }

  function setFeature(id, patch){
    var f = state.features.find(function(x){return x.id===id;});
    if(f){ Object.assign(f, patch); save(); }
  }

  function addSubscriptionRequest(userId, featureId){
    var f = state.features.find(function(x){return x.id===featureId;});
    var req = { id:"r"+Date.now(), userId:userId, feature:featureId, featureName:f?f.name:featureId, t:Date.now(), status:"pending" };
    state.subscriptionRequests.unshift(req);
    save();
    return req;
  }

  function resolveSubscription(id, status){
    var r = state.subscriptionRequests.find(function(x){return x.id===id;});
    if(r){ r.status=status; save(); }
  }

  function applyModeration(userId, action, reason, durationMs){
    var m = state.members.find(function(x){return x.id===userId;});
    if(!m) return;
    m.state = (action==="APP_SUSPENSION") ? "suspended" : (action==="FULL_COMMUNICATION_MUTE" ? "restricted" : "muted");
    m.mute = action; m.reason = reason||""; m.until = durationMs?Date.now()+durationMs:0;
    state.moderationLog.unshift({id:"lg"+Date.now(), admin:"owner", action:action, target:userId, reason:reason||"", t:Date.now()});
    save();
  }

  function liftModeration(userId){
    var m = state.members.find(function(x){return x.id===userId;});
    if(m){ m.state="active"; m.mute=null; m.reason=""; m.until=0; save(); }
  }

  function i18n(key){
    var lang = state.me.lang || "ar";
    var tbl = LOYED_I18N[lang] || LOYED_I18N.ar;
    return tbl[key] || LOYED_I18N.ar[key] || key;
  }

  function fmtTime(ts){
    var d = new Date(ts);
    var now = new Date();
    var diff = now - d;
    if(diff < 60000) return "الآن";
    if(diff < 3600000) return Math.floor(diff/60000)+" د";
    if(d.toDateString() === now.toDateString()){
      var h = String(d.getHours()).padStart(2,"0");
      var m = String(d.getMinutes()).padStart(2,"0");
      return h+":"+m;
    }
    if(diff < 86400000*7) return ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"][d.getDay()];
    return d.toLocaleDateString();
  }

  function fmtLastSeen(ts){
    if(!ts) return "";
    var diff = Date.now()-ts;
    if(diff<60000) return "الآن";
    if(diff<3600000) return "آخر ظهور قبل "+Math.floor(diff/60000)+" د";
    if(diff<86400000) return "آخر ظهور قبل "+Math.floor(diff/3600000)+" س";
    return "آخر ظهور "+new Date(ts).toLocaleDateString();
  }

  function avatarColor(n){
    var colors = [
      "linear-gradient(135deg,#b14bff,#7b2fff)",
      "linear-gradient(135deg,#0ea5e9,#2563eb)",
      "linear-gradient(135deg,#ec4899,#db2777)",
      "linear-gradient(135deg,#f59e0b,#d97706)",
      "linear-gradient(135deg,#10b981,#059669)",
      "linear-gradient(135deg,#6366f1,#4f46e5)",
      "linear-gradient(135deg,#ef4444,#b91c1c)",
      "linear-gradient(135deg,#14b8a6,#0d9488)",
      "linear-gradient(135deg,#8b5cf6,#6d28d9)",
      "linear-gradient(135deg,#06b6d4,#0891b2)",
    ];
    return colors[n%colors.length];
  }

  function initials(name){
    if(!name) return "?";
    var parts = name.trim().split(/\s+/);
    if(parts.length===1) return parts[0].charAt(0).toUpperCase();
    return (parts[0].charAt(0)+parts[1].charAt(0)).toUpperCase();
  }

  return {
    init:init, save:save, reset:reset, get:get, set:set, t:t,
    findContact:findContact, findChat:findChat,
    sendMsg:sendMsg, deleteMsg:deleteMsg, editMsg:editMsg,
    setChatMute:setChatMute, togglePin:togglePin, markRead:markRead, createChat:createChat,
    setTheme:setTheme, setLang:setLang, setMe:setMe,
    setFeature:setFeature, addSubscriptionRequest:addSubscriptionRequest, resolveSubscription:resolveSubscription,
    applyModeration:applyModeration, liftModeration:liftModeration,
    i18n:i18n, fmtTime:fmtTime, fmtLastSeen:fmtLastSeen,
    avatarColor:avatarColor, initials:initials,
  };
})();
