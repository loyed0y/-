LOYED Android build package
1. Upload this ZIP to the root of https://github.com/loyed0y/-
2. Keep the filename exactly: LOYED-Android-Ready-to-upload.zip
3. Commit the upload. The repository's GitHub Actions workflow will extract it and build a debug APK.
4. After the workflow succeeds, download Artifacts > LOYED-debug-APK.
This is a wrapper around the current frontend prototype; backend-dependent features remain simulated until backend services are implemented.
